import base64 as b

id   = b.b64decode('cGx1Z2luLnZpZGVvLmlwdHZub3c=')

name = b.b64decode('SVBUViBOb3c=')

host = b.b64decode('aHR0cDovL2lwdHZub3cuZGRucy5uZXQ=')

port = b.b64decode('NDU0NQ==')